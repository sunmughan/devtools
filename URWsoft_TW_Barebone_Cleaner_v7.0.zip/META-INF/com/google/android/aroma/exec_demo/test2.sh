echo " "
mkdir -p /sdcard/URWsoft
echo " "
exit 10

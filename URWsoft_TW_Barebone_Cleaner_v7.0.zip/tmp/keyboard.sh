#!/sbin/sh
# Script by Edgarf28. Thanks for that

chown 0:0 /system/lib/libloadStylusCore.so
chmod 644 /system/lib/libloadStylusCore.so
chcon u:object_r:system_library_file:s0 /system/lib/libloadStylusCore.so

chown 0:0 /system/lib/libswiftkeysdk-java.so
chmod 644 /system/lib/libswiftkeysdk-java.so
chcon u:object_r:system_library_file:s0 /system/lib/libswiftkeysdk-java.so

sync
